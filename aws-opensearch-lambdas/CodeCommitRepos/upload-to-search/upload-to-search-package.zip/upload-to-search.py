import boto3
import re
import os
import requests
from requests_aws4auth import AWS4Auth

region = 'us-east-1'  
service = 'es'
credentials = boto3.Session().get_credentials()

awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
print("Credentials access key:", credentials.access_key)
print("Credentials secret key:", credentials.secret_key)

host = os.environ.get('SEARCH_DOMAIN')
index = 'articles'
datatype = '_doc'
url = host + '/' + index + '/' + datatype

headers = { "Content-Type": "application/json" }

s3 = boto3.client('s3')
author = ''
date = ''


# Lambda execution starts here
def handler(event, context):
    for record in event['Records']:

        # Get the bucket name and key for the new file
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Get, read, and split the file into lines
        obj = s3.get_object(Bucket=bucket, Key=key)
        body = obj['Body'].read()
        lines = body.splitlines()
        
        author = lines[1] if len(lines) > 1 else 'Unknown'
        date = lines[2] if len(lines) > 2 else '1900/01/01'
        print("Author:" , author)
        print("Date:", date)
        print("Body:", body)
        document = { "Author": author, "\nDate": date, "\nBody": body }
        print("Document:",document)
        r = requests.post(url, auth=awsauth, json=document, headers=headers)
        print("Response:", r.text)
